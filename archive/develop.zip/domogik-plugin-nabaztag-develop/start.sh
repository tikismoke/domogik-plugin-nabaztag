export PYTHONPATH=/var/lib/domogik && /usr/bin/python bin/nabaztag.py -f
