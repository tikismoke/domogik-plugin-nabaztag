domogik-plugin-nabaztag
=======================

A domogik (www.domogik.org) plugin to interact with nabaztag:

- Sleep.
- Wakeup.
- Move ears.
- Send TTS.
- Change led color. (not yet)
